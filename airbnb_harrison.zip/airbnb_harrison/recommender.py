# recommender.py
import ast
from user_property_harrison import User, Property
from datetime import datetime


def score_property(user: User, prop: Property):
    """
    Simple scoring based on budget and tag matches.
    Higher score = better fit.
    """
    budget_range = ast.literal_eval(user.budget_range) 
    min_budget = budget_range[0]
    max_budget = budget_range[1]

    start_str, end_str = user.travel_dates.split(" to ")
    start_date = datetime.strptime(start_str, "%Y-%m-%d")
    end_date = datetime.strptime(end_str, "%Y-%m-%d")
    days = (end_date - start_date).days

    total_cost = prop.price_per_night * days

    if total_cost >= min_budget and total_cost <= max_budget:
        return 0  # over budget, no fit

    # Score: number of matched tags + features
    score = 0
    if user.preferred_environment in prop.tags:
        score += 1  # environment match is important

    return score


def get_recommendations(user: User, properties: list, top_n=5):
    scored = [(prop, score_property(user, prop)) for prop in properties]
    # Sort descending by score
    scored = [x for x in scored if x[1] > 0]
    scored.sort(key=lambda x: x[1], reverse=True)
    return [prop for prop, score in scored[:top_n]]
