import streamlit as st
from user_property_harrison import User, Property
import database_harrison
from recommender import get_recommendations

# -------------------------------
# Helper functions for display
# -------------------------------

def display_user(user):
    st.write(f"**ID:** {user.user_id} | **Name:** {user.name} | **Group:** {user.group_size} | **Env:** {user.preferred_environment} | **Budget:** ${user.budget_range}| **Dates** {user.travel_dates}")

def display_property(prop):
    st.write(
    f"**ID:** {prop.property_id} {prop.name} | {prop.type.title()} in {prop.location} | ${prop.price_per_night:.2f}/night"
)    
    st.write(f"  Features: {', '.join(prop.features)}")
    st.write(f"  Tags: {', '.join(prop.tags)}")

    # -------------------------------
# Main app
# -------------------------------

def main():
    st.title("🏖️ Vacation Rental Recommender")

    # Initialize database and load data
    database_harrison.create_tables()
    database_harrison.load_json_to_db()
    users = database_harrison.load_users()
    properties = database_harrison.load_properties()

    menu = ["Home", "Create User", "View Users", "Delete User", "View Properties", "Get Recommendations"]
    choice = st.sidebar.selectbox("Menu", menu)

    # -------------------------------
    # Create User
    # -------------------------------
    if choice == "Create User":
        st.subheader("Create a New User Profile")
        user_id = st.number_input("User ID (integer)", min_value=1, step=1)
        name = st.text_input("Name")
        group_size = st.number_input("Group size", min_value=1, step=1)
        preferred_env = st.selectbox("Preferred environment", ["mountain", "lake", "beach", "city"])
        budget_range = st.text_input("Budget range ([min, max])")
        travel_dates = st.text_input("Travel dates (XXXX-XX-XX to YYYY-YY-YY)")

        if st.button("Create User"):
            user = User(user_id, name, group_size, preferred_env.lower(), budget_range, travel_dates)
            database_harrison.insert_user(user)
            users = database_harrison.load_users()
            st.success(f"User {name} created successfully!")

     # -------------------------------
    # View Users
    # -------------------------------
    elif choice == "View Users":
        st.subheader("All Users")
        if not users:
            st.info("No users found.")
        else:
            for u in users:
                display_user(u)

    # -------------------------------
    # Delete User
    # -------------------------------
    elif choice == "Delete User":
        st.subheader("Delete User Profile")
        del_id = st.number_input("Enter User ID to delete", min_value=1, step=1)
        if st.button("Delete User"):
            database_harrison.delete_user(del_id)
            st.success(f"User {del_id} deleted (if existed).")

    # -------------------------------
    # View Properties
    # -------------------------------
    elif choice == "View Properties":
        st.subheader("All Properties")
        if not properties:
            st.info("No properties found.")
        else:
            for p in properties:
                display_property(p)

    # -------------------------------
    # Get Recommendations
    # -------------------------------
    elif choice == "Get Recommendations":
        st.subheader("Get Property Recommendations")
        rec_user_id = st.number_input("Enter your User ID", min_value=1, step=1)
        if st.button("Get Recommendations"):
            user = next((u for u in users if u.user_id == rec_user_id), None)
            if not user:
                st.error("User not found.")
            else:
                recs = get_recommendations(user, properties)
                if not recs:
                    st.info("No suitable properties found for you.")
                else:
                    st.success(f"Top {len(recs)} recommendations for {user.name}:")
                    for prop in recs:
                        display_property(prop)

if __name__ == "__main__":
    main()